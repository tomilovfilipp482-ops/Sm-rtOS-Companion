#!/usr/bin/env bash
set -euo pipefail
if ! command -v gradle >/dev/null 2>&1; then
  echo "Gradle не найден. Открой проект в Android Studio и выполни Build > Build APK(s)." >&2
  exit 2
fi
gradle --no-daemon :app:assembleDebug
echo "APK: app/build/outputs/apk/debug/app-debug.apk"
