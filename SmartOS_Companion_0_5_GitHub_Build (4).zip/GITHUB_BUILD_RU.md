# Как собрать SmartOS Companion APK через GitHub

1. На GitHub создай новый репозиторий `SmartOS-Companion`.
2. Выбери Public или Private. Не добавляй README, .gitignore или лицензию.
3. Распакуй этот ZIP на HONOR через файловый менеджер.
4. В репозитории нажми Add file → Upload files и загрузи содержимое папки проекта. Сохрани структуру `.github/workflows/android-apk.yml`.
5. Нажми Commit changes.
6. Открой Actions → Build SmartOS Companion APK. Если запуск не начался автоматически, нажми Run workflow.
7. После успешного запуска открой его и скачай артефакт `SmartOS-Companion-debug-APK`.
8. Распакуй артефакт и установи `app-debug.apk` на HONOR.

Если мобильный GitHub не даёт загрузить скрытую папку `.github`, напиши мне — предложу другой путь.

Важно: это debug-сборка для проверки. Успешная сборка не гарантирует, что приложение уже протестировано на HONOR. Не удаляй старую версию приложения с важными данными, если Android сообщит о несовпадении подписи. SmartOS не заменяет прошивку Mi Band 8 и не отключает Mi Fitness.
