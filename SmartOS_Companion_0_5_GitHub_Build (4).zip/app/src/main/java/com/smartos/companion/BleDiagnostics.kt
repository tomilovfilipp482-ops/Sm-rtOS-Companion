package com.smartos.companion

import android.Manifest
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothManager
import android.bluetooth.le.ScanCallback
import android.bluetooth.le.ScanResult
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import androidx.core.content.ContextCompat

/** Short, user-started BLE discovery only. No pairing, GATT, authentication or writes. */
class BleDiagnostics(private val context: Context) {
    private val adapter: BluetoothAdapter? =
        (context.getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager).adapter
    private var callback: ScanCallback? = null
    private val handler = Handler(Looper.getMainLooper())
    private var finishCallback: (() -> Unit)? = null
    private val seenDevices = linkedSetOf<String>()
    private val stopTask = Runnable {
        stopScanOnly()
        finishCallback?.invoke()
        finishCallback = null
    }

    fun requiredPermissions(): Array<String> = if (Build.VERSION.SDK_INT >= 31)
        arrayOf(Manifest.permission.BLUETOOTH_SCAN, Manifest.permission.BLUETOOTH_CONNECT)
    else arrayOf(Manifest.permission.ACCESS_FINE_LOCATION)

    fun hasPermissions(): Boolean = requiredPermissions().all {
        ContextCompat.checkSelfPermission(context, it) == PackageManager.PERMISSION_GRANTED
    }

    fun bluetoothEnabled(): Boolean = runCatching { adapter?.isEnabled == true }.getOrDefault(false)

    /** Scans for at most 10 seconds and reports each device once to avoid UI/battery churn. */
    fun scan(onResult: (String) -> Unit, onFinished: () -> Unit) {
        stop()
        val scanner = adapter?.bluetoothLeScanner
        if (scanner == null) { onResult("Bluetooth LE недоступен"); onFinished(); return }
        if (!bluetoothEnabled()) { onResult("Сначала включи Bluetooth"); onFinished(); return }
        if (!hasPermissions()) { onResult("Нет разрешений Bluetooth"); onFinished(); return }

        seenDevices.clear()
        finishCallback = onFinished
        val scanCallback = object : ScanCallback() {
            override fun onScanResult(callbackType: Int, result: ScanResult) {
                val address = runCatching { result.device.address }.getOrNull() ?: return
                if (!seenDevices.add(address)) return
                val name = runCatching { result.device.name }.getOrNull()
                    ?: result.scanRecord?.deviceName ?: "Устройство без имени"
                onResult("$name • $address • RSSI ${result.rssi} dBm")
            }
            override fun onScanFailed(errorCode: Int) {
                onResult("Ошибка BLE-сканирования: $errorCode")
                stopScanOnly()
                finishCallback?.invoke()
                finishCallback = null
            }
        }
        callback = scanCallback
        runCatching {
            scanner.startScan(scanCallback)
            handler.postDelayed(stopTask, 10_000L)
        }.onFailure {
            stopScanOnly()
            finishCallback = null
            onResult("Не удалось начать сканирование: ${it.javaClass.simpleName}")
            onFinished()
        }
    }

    private fun stopScanOnly() {
        handler.removeCallbacks(stopTask)
        val cb = callback ?: return
        runCatching { adapter?.bluetoothLeScanner?.stopScan(cb) }
        callback = null
    }

    fun stop() {
        stopScanOnly()
        finishCallback = null
    }
}
