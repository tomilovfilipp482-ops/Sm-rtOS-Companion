package com.smartos.companion

import android.Manifest
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.graphics.BitmapFactory
import android.bluetooth.BluetoothManager
import android.content.Context
import android.content.pm.PackageManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.unit.dp
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import java.text.DateFormat
import java.util.Date

class MainActivity : ComponentActivity() {
    private var resumeTick by mutableIntStateOf(0)

    override fun onResume() {
        super.onResume()
        resumeTick++
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { SmartOSApp() }
    }

    @OptIn(ExperimentalMaterial3Api::class)
    @Composable private fun SmartOSApp() {
        var tab by remember { mutableStateOf("Обзор") }
        var refresh by remember { mutableIntStateOf(0) }
        var selectedImage by remember { mutableStateOf<String?>(null) }
        var scanText by remember { mutableStateOf("Сканирование ещё не запускалось") }
        var scanning by remember { mutableStateOf(false) }
        var notificationQuery by remember { mutableStateOf("") }
        var scanResults by remember { mutableStateOf(listOf<String>()) }
        val ble = remember { BleDiagnostics(this) }
        DisposableEffect(ble) { onDispose { ble.stop() } }
        val lifecycleRefresh = resumeTick
        val notices = remember(refresh, lifecycleRefresh) { NotificationStore.read(this) }
        val sources = remember(refresh, lifecycleRefresh) { NotificationStore.sources(this) }
        val scanPermissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { grants ->
            if (grants.values.all { it }) {
                scanResults = emptyList(); scanning = true; scanText = "Поиск до 10 секунд…"
                ble.scan({ result -> scanResults = scanResults + result }, { scanning = false; scanText = "Поиск завершён" })
            }
        }
        MaterialTheme {
            Scaffold(topBar = { TopAppBar(title = { Text("SmartOS Companion 0.5") }) }) { padding ->
                Column(Modifier.padding(padding).fillMaxSize()) {
                    TabRow(selectedTabIndex = listOf("Обзор", "Уведомления", "Источники", "Диагностика").indexOf(tab).coerceAtLeast(0)) {
                        listOf("Обзор", "Уведомления", "Источники", "Диагностика").forEach { label ->
                            Tab(selected = tab == label, onClick = { tab = label }, text = { Text(label) })
                        }
                    }
                    when (tab) {
                        "Обзор" -> Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                            Card(Modifier.fillMaxWidth()) {
                                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                    Text("Две системы — одна связка", style = MaterialTheme.typography.titleLarge)
                                    Text("Xiaomi остаётся главной системой браслета. SmartOS дополняет её на телефоне и не меняет прошивку Mi Band 8.")
                                    Text("Данные и копии уведомлений SmartOS хранятся локально на этом телефоне.", style = MaterialTheme.typography.bodySmall)
                                }
                            }
                            Text("Состояние связки", style = MaterialTheme.typography.titleMedium)
                            StatusLine("Mi Fitness", isPackageInstalled("com.xiaomi.wearable"), "Приложение найдено")
                            StatusLine("Доступ SmartOS к уведомлениям", isNotificationAccessEnabled(), "Разрешение Android")
                            StatusLine("Bluetooth", ble.bluetoothEnabled(), "Связь с браслетом поддерживается через Mi Fitness")
                            StatusLine("Работа SmartOS без ограничений батареи", isIgnoringBatteryOptimizations(), "Для фоновой работы")
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                                Button(onClick = { openMiFitness() }, modifier = Modifier.weight(1f)) { Text("Открыть Mi Fitness") }
                                OutlinedButton(onClick = { startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)) }, modifier = Modifier.weight(1f)) { Text("Доступ к уведомлениям") }
                            }
                            OutlinedButton(onClick = { tab = "Диагностика" }, modifier = Modifier.fillMaxWidth()) { Text("Полная диагностика") }
                            Card(Modifier.fillMaxWidth()) {
                                Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                    Text("Как распределены функции", style = MaterialTheme.typography.titleSmall)
                                    Text("""• Браслет и Mi Fitness: время, циферблаты, датчики, тренировки и штатные уведомления.
• SmartOS: копия уведомлений, поиск, фильтры, локальная история и диагностика.
• Прямое управление прошивкой браслета пока не включено.""", style = MaterialTheme.typography.bodySmall)
                                }
                            }
                        }
                        "Уведомления" -> Column(Modifier.fillMaxSize().padding(horizontal = 14.dp)) {
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text("Сохранено: ${notices.size} / 250", style = MaterialTheme.typography.titleSmall)
                                TextButton(onClick = { NotificationStore.clear(this@MainActivity); refresh++ }) { Text("Очистить") }
                            }
                            OutlinedTextField(
                                value = notificationQuery,
                                onValueChange = { notificationQuery = it },
                                modifier = Modifier.fillMaxWidth(),
                                singleLine = true,
                                label = { Text("Поиск по уведомлениям") }
                            )
                            val visibleNotices = notices.filter { notice ->
                                NotificationStore.isSourceEnabled(this@MainActivity, notice.packageName) &&
                                    (notificationQuery.isBlank() || notice.app.contains(notificationQuery, true) ||
                                        notice.title.contains(notificationQuery, true) || notice.text.contains(notificationQuery, true))
                            }
                            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                items(visibleNotices, key = { it.id }) { item ->
                                    Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp)) {
                                        Column(Modifier.padding(12.dp)) {
                                            Text(item.app, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.primary)
                                            if (item.title.isNotBlank()) Text(item.title, style = MaterialTheme.typography.titleMedium)
                                            if (item.text.isNotBlank()) Text(item.text)
                                            if (item.imagePath != null) {
                                                Spacer(Modifier.height(6.dp))
                                                Text("📷 Изображение из уведомления", color = MaterialTheme.colorScheme.primary)
                                                Text("Открыть фото", modifier = Modifier.clickable { selectedImage = item.imagePath }, style = MaterialTheme.typography.labelLarge)
                                            }
                                            Text(DateFormat.getDateTimeInstance(DateFormat.SHORT, DateFormat.SHORT).format(Date(item.time)), style = MaterialTheme.typography.labelSmall)
                                        }
                                    }
                                }
                            }
                        }
                        "Источники" -> Column(Modifier.fillMaxSize().padding(16.dp)) {
                            Text("Выбери, какие приложения показывать в ленте. Сбор Android-уведомлений остаётся системным.")
                            Spacer(Modifier.height(8.dp))
                            LazyColumn {
                                items(sources, key = { it.first }) { (pkg, label) ->
                                    Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                                        Column(Modifier.weight(1f)) { Text(label); Text(pkg, style = MaterialTheme.typography.labelSmall) }
                                        Switch(checked = NotificationStore.isSourceEnabled(this@MainActivity, pkg), onCheckedChange = { NotificationStore.setSourceEnabled(this@MainActivity, pkg, it); refresh++ })
                                    }
                                    Divider()
                                }
                            }
                            Text("Список формируется по приложениям, от которых уже поступали уведомления.", style = MaterialTheme.typography.bodySmall)
                        }
                        else -> Column(Modifier.fillMaxSize().padding(16.dp)) {
                            Text("Проверка разрешений", style = MaterialTheme.typography.titleLarge)
                            Spacer(Modifier.height(8.dp))
                            DiagnosticRow("Доступ к уведомлениям", isNotificationAccessEnabled(), "Открыть настройки") {
                                startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
                            }
                            DiagnosticRow("Bluetooth включён", ble.bluetoothEnabled(), "Настройки Bluetooth") {
                                startActivity(Intent(Settings.ACTION_BLUETOOTH_SETTINGS))
                            }
                            DiagnosticRow("Разрешения BLE", ble.hasPermissions(), "Разрешить") {
                                scanPermissionLauncher.launch(ble.requiredPermissions())
                            }
                            DiagnosticRow("Mi Fitness установлено", isPackageInstalled("com.xiaomi.wearable"), "Открыть") {
                                runCatching { openMiFitness() }
                            }
                            DiagnosticRow("Работа без ограничений батареи", isIgnoringBatteryOptimizations(), "Настройки батареи") {
                                startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
                            }
                            DiagnosticRow("Уведомления приложения", NotificationManagerCompat.from(this@MainActivity).areNotificationsEnabled(), "Настройки приложения") {
                                startActivity(Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE, packageName))
                            }
                            Spacer(Modifier.height(12.dp))
                            Button(onClick = {
                                scanResults = emptyList()
                                if (ble.hasPermissions()) {
                                    scanning = true; scanText = "Поиск до 10 секунд…"
                                    ble.scan({ result -> scanResults = scanResults + result }, { scanning = false; scanText = "Поиск завершён" })
                                } else scanPermissionLauncher.launch(ble.requiredPermissions())
                            }, enabled = !scanning, modifier = Modifier.fillMaxWidth()) { Text(if (scanning) "Сканирую…" else "Найти BLE-устройства (только просмотр)") }
                            OutlinedButton(onClick = { ble.stop(); scanning = false; scanText = "Сканирование остановлено" }, modifier = Modifier.fillMaxWidth()) { Text("Остановить сканирование") }
                            Text(scanText, style = MaterialTheme.typography.bodySmall)
                            scanResults.forEach { Text(it, style = MaterialTheme.typography.bodySmall) }
                            Spacer(Modifier.height(8.dp))
                            Text("Рекомендации для Mi Band 8", style = MaterialTheme.typography.titleMedium)
                            Text("• Оставь браслет привязанным в Mi Fitness.\n• В Mi Fitness включи уведомления нужных приложений.\n• Разреши Mi Fitness работу в фоне и автозапуск в настройках HONOR.\n• Не ограничивай Bluetooth для Mi Fitness и не закрывай его принудительно.\n• SmartOS Companion хранит копию уведомлений только на телефоне.", style = MaterialTheme.typography.bodySmall)
                            Text("Важно: обнаружение BLE не означает, что браслет доступен для управления. Приложение не подключается к GATT, не выполняет сопряжение и не записывает команды в браслет.", style = MaterialTheme.typography.bodySmall)
                            Spacer(Modifier.height(8.dp))
                            Text("Фото сохраняются локально только если приложение-источник вложило изображение в Android-уведомление. Остальные вложения не извлекаются из личных чатов.", style = MaterialTheme.typography.bodySmall)
                        }
                    }
                }
            }
            selectedImage?.let { path ->
                AlertDialog(onDismissRequest = { selectedImage = null }, confirmButton = { TextButton(onClick = { selectedImage = null }) { Text("Закрыть") } }, title = { Text("Фото из уведомления") }, text = {
                    val bitmap = remember(path) { BitmapFactory.decodeFile(path) }
                    if (bitmap != null) Image(bitmap.asImageBitmap(), contentDescription = "Изображение из уведомления", modifier = Modifier.fillMaxWidth().heightIn(max = 420.dp))
                    else Text("Изображение больше недоступно")
                })
            }
        }
    }

    @Composable private fun StatusLine(title: String, ok: Boolean, detail: String) {
        Row(Modifier.fillMaxWidth().padding(vertical = 3.dp), horizontalArrangement = Arrangement.SpaceBetween) {
            Column(Modifier.weight(1f)) {
                Text(title, style = MaterialTheme.typography.bodyMedium)
                Text(detail, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Text(if (ok) "Доступно" else "Проверить", style = MaterialTheme.typography.labelMedium,
                color = if (ok) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error)
        }
    }

    private fun openMiFitness() {
        val launch = packageManager.getLaunchIntentForPackage("com.xiaomi.wearable")
        if (launch != null) startActivity(launch)
        else startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:com.xiaomi.wearable")))
    }

    @Composable private fun DiagnosticRow(title: String, ok: Boolean, action: String, onClick: () -> Unit) {
        Row(Modifier.fillMaxWidth().padding(vertical = 5.dp), horizontalArrangement = Arrangement.SpaceBetween) {
            Column(Modifier.weight(1f)) { Text(title); Text(if (ok) "Разрешено / доступно" else "Требует проверки", style = MaterialTheme.typography.labelSmall, color = if (ok) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error) }
            TextButton(onClick = onClick) { Text(action) }
        }
        Divider()
    }

    private fun isIgnoringBatteryOptimizations(): Boolean =
        (getSystemService(Context.POWER_SERVICE) as PowerManager).isIgnoringBatteryOptimizations(packageName)

    private fun isNotificationAccessEnabled(): Boolean =
        NotificationManagerCompat.getEnabledListenerPackages(this).contains(packageName)

    private fun isPackageInstalled(pkg: String): Boolean = runCatching {
        if (Build.VERSION.SDK_INT >= 33) packageManager.getPackageInfo(pkg, android.content.pm.PackageManager.PackageInfoFlags.of(0))
        else packageManager.getPackageInfo(pkg, 0)
    }.isSuccess
}
