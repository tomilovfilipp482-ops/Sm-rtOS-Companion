package com.smartos.companion

import android.app.Notification
import android.graphics.Bitmap
import android.os.Build
import android.os.Bundle
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import java.io.File
import java.io.FileOutputStream

class PhoneNotificationListener : NotificationListenerService() {
    override fun onNotificationPosted(sbn: StatusBarNotification) {
        if (sbn.packageName == packageName) return
        val n = sbn.notification ?: return
        val extras = n.extras ?: Bundle()
        val title = extras.getCharSequence(Notification.EXTRA_TITLE)?.toString().orEmpty()
        val text = sequenceOf(
            extras.getCharSequence(Notification.EXTRA_BIG_TEXT)?.toString(),
            extras.getCharSequence(Notification.EXTRA_TEXT)?.toString(),
            extras.getCharSequence(Notification.EXTRA_SUB_TEXT)?.toString()
        ).filterNotNull().firstOrNull { it.isNotBlank() }.orEmpty()
        val bitmap = extractPicture(n)
        val imagePath = bitmap?.let { savePreview(it, sbn.key.hashCode().toLong(), sbn.postTime) }
        if (title.isBlank() && text.isBlank() && imagePath == null) return
        val appLabel = runCatching {
            packageManager.getApplicationLabel(packageManager.getApplicationInfo(sbn.packageName, 0)).toString()
        }.getOrDefault(sbn.packageName)
        NotificationStore.add(applicationContext, Notice(
            sbn.key.hashCode().toLong(), sbn.packageName, appLabel, title, text, sbn.postTime, imagePath
        ))
    }

    private fun extractPicture(notification: Notification): Bitmap? {
        val extras = notification.extras ?: return null
        (extras.get(Notification.EXTRA_PICTURE) as? Bitmap)?.let { return it }
        if (Build.VERSION.SDK_INT >= 31) {
            val icon = extras.getParcelable<android.graphics.drawable.Icon>(Notification.EXTRA_PICTURE_ICON)
            if (icon != null) return runCatching {
                val drawable = icon.loadDrawable(this) ?: return@runCatching null
                val w = (drawable.intrinsicWidth.takeIf { it > 0 } ?: 512).coerceAtMost(1024)
                val h = (drawable.intrinsicHeight.takeIf { it > 0 } ?: 512).coerceAtMost(1024)
                Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888).also { bitmap ->
                    val canvas = android.graphics.Canvas(bitmap)
                    drawable.setBounds(0, 0, w, h); drawable.draw(canvas)
                }
            }.getOrNull()
        }
        return null
    }

    private fun savePreview(source: Bitmap, key: Long, timestamp: Long): String? = runCatching {
        val maxSide = 720
        val scale = minOf(1f, maxSide.toFloat() / maxOf(source.width, source.height))
        val preview = Bitmap.createScaledBitmap(source,
            (source.width * scale).toInt().coerceAtLeast(1),
            (source.height * scale).toInt().coerceAtLeast(1), true)
        val dir = File(filesDir, "notification_images").apply { mkdirs() }
        val file = File(dir, "notice_${key}_$timestamp.jpg")
        FileOutputStream(file).use { preview.compress(Bitmap.CompressFormat.JPEG, 84, it) }
        dir.listFiles()?.sortedByDescending { it.lastModified() }?.drop(250)?.forEach { it.delete() }
        file.absolutePath
    }.getOrNull()
}
