package com.smartos.companion

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/** Local-only store. Notification contents and image paths never leave this app. */
data class Notice(
    val id: Long,
    val packageName: String,
    val app: String,
    val title: String,
    val text: String,
    val time: Long,
    val imagePath: String? = null
)

object NotificationStore {
    private const val PREFS = "smartos_notifications"
    private const val KEY = "items"
    private const val FILTERS = "enabled_sources"

    @Synchronized fun add(context: Context, notice: Notice) {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val old = JSONArray(prefs.getString(KEY, "[]"))
        val merged = JSONArray()
        for (i in 0 until old.length()) {
            val o = old.getJSONObject(i)
            if (o.optLong("id") != notice.id) merged.put(o)
        }
        merged.put(JSONObject().apply {
            put("id", notice.id); put("packageName", notice.packageName); put("app", notice.app)
            put("title", notice.title); put("text", notice.text); put("time", notice.time)
            put("imagePath", notice.imagePath ?: JSONObject.NULL)
        })
        val trimmed = JSONArray()
        for (i in maxOf(0, merged.length() - 250) until merged.length()) trimmed.put(merged.getJSONObject(i))
        prefs.edit().putString(KEY, trimmed.toString()).apply()
    }

    fun read(context: Context): List<Notice> {
        val arr = JSONArray(context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY, "[]"))
        return (0 until arr.length()).mapNotNull { i -> runCatching {
            val o = arr.getJSONObject(i)
            Notice(o.getLong("id"), o.optString("packageName"), o.getString("app"),
                o.optString("title"), o.optString("text"), o.getLong("time"),
                if (o.isNull("imagePath")) null else o.getString("imagePath"))
        }.getOrNull() }.sortedByDescending { it.time }
    }

    fun sources(context: Context): List<Pair<String, String>> = read(context)
        .distinctBy { it.packageName }.map { it.packageName to it.app }.sortedBy { it.second.lowercase() }

    fun isSourceEnabled(context: Context, packageName: String): Boolean =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getStringSet(FILTERS, null)
            ?.contains(packageName)?.not() ?: true

    fun setSourceEnabled(context: Context, packageName: String, enabled: Boolean) {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val set = (prefs.getStringSet(FILTERS, null) ?: emptySet()).toMutableSet()
        // FILTERS stores disabled package names; unseen sources remain enabled by default.
        if (enabled) set.remove(packageName) else set.add(packageName)
        prefs.edit().putStringSet(FILTERS, set).apply()
    }

    fun hasExplicitFilter(context: Context, packageName: String): Boolean =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getStringSet(FILTERS, null)?.contains(packageName) == true

    fun clear(context: Context) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().remove(KEY).apply()
        context.filesDir.resolve("notification_images").deleteRecursively()
    }
}
