@echo off
where gradle >nul 2>nul || (echo Gradle not found. Open this project in Android Studio and choose Build ^> Build APK(s). & exit /b 2)
gradle --no-daemon :app:assembleDebug
if errorlevel 1 exit /b %errorlevel%
echo APK: app\build\outputs\apk\debug\app-debug.apk
